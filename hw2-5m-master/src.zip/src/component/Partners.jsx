import Partners1 from '../img/Partners1.png'
import Partners2 from '../img/Partners2.png'
import Partners3 from '../img/Partners3.png'
import Partners4 from '../img/Partners4.png'



export default function Partners() {
  return (
    <div className='Partners-img'>
       <img className='img1' src={Partners1} alt="item" /> 
        <img className='img2'   src={Partners2} alt="item" /> 
       <img className='img3' src={Partners3} alt="item" /> 
       <img className='img4' src={Partners4} alt="item" /> 

    </div>
  )
}
